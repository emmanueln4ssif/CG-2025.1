// player.js
import * as THREE from 'three';
import { setupPointerLock } from './player.js';

export function createPlayer(controls) {
  return {
    controls,
    position: new THREE.Vector3(0, 8, 0),
    velocity: new THREE.Vector3(),
    speed: 50,
    height: 8,
    radius: 0.5,
    jumpForce: 20,
    gravity: -20,
    isOnGround: false,
    canJump: true,
    moveForward: false,
    moveBackward: false,
    moveLeft: false,
    moveRight: false,
    jumpRequested: false,
  };
}

export function updatePlayer(player, camera, raycaster, collisionObjects, delta) {
  if (!player.controls.isLocked) return;

  const playerObj = player.controls.getObject();
  const playerPos = playerObj.position;

  // Gravidade
  player.velocity.y += player.gravity * delta;

  // Verificação de chão
  raycaster.set(playerPos, new THREE.Vector3(0, -1, 0));
  raycaster.far = player.height * 0.6;
  const downIntersects = raycaster.intersectObjects(collisionObjects);

  player.canJump = false;
  player.isOnGround = false;
  let onRamp = false;
  let rampNormal = new THREE.Vector3(0, 1, 0);

  if (downIntersects.length > 0 && downIntersects[0].distance <= player.height * 0.6) {
    const intersect = downIntersects[0];

    if (player.velocity.y <= 0.1 || intersect.object.userData.type === 'Ramp') {
      playerPos.y = intersect.point.y + (player.height * 0.5);
      player.velocity.y = 0;
      player.isOnGround = true;
      player.canJump = true;
    }

    if (intersect.object.userData.type === 'Ramp' && intersect.face) {
      onRamp = true;
      rampNormal = intersect.face.normal.clone();
    }
  }

  // Direção de movimento
  const moveDirection = new THREE.Vector3(
    (player.moveLeft ? -1 : 0) + (player.moveRight ? 1 : 0),
    0,
    (player.moveForward ? -1 : 0) + (player.moveBackward ? 1 : 0)
  ).normalize();

  const cameraQuaternion = new THREE.Quaternion();
  camera.getWorldQuaternion(cameraQuaternion);
  moveDirection.applyQuaternion(cameraQuaternion);
  moveDirection.y = 0;
  moveDirection.normalize();

  let moveVector = moveDirection.multiplyScalar(player.speed * delta);

  // Rampas
  if (onRamp) {
    const angle = Math.acos(rampNormal.dot(new THREE.Vector3(0, 1, 0)));
    if (angle < Math.PI / 4) {
      const projectedMove = moveVector.clone().projectOnPlane(rampNormal);
      moveVector.copy(projectedMove);
      moveVector.y += Math.sin(angle) * player.speed * delta * 0.5;
    }
  }

  const newPos = checkHorizontalCollision(player, playerPos, moveVector, raycaster, collisionObjects);
  playerPos.copy(newPos);

  // Pulo
  if (player.jumpRequested && player.canJump) {
    player.velocity.y = player.jumpForce;
    player.canJump = false;
    player.isOnGround = false;
    player.jumpRequested = false;
  }

  if (!onRamp) {
    player.velocity.y += player.gravity * delta;
  }
  playerPos.y += player.velocity.y * delta;
}

export function movementControls(event, player, value) {
  switch (event.code) {
    case 'KeyW':
    case 'ArrowUp':
      player.moveForward = value;
      break;
    case 'KeyS':
    case 'ArrowDown':
      player.moveBackward = value;
      break;
    case 'KeyA':
    case 'ArrowLeft':
      player.moveLeft = value;
      break;
    case 'KeyD':
    case 'ArrowRight':
      player.moveRight = value;
      break;
    case 'Space':
      if (value && player.canJump && player.isOnGround) {
        player.jumpRequested = true;
      }
      break;
  }
}

export function setupPointerLock(renderer, controls, orbit) {
  const element = renderer.domElement;
  const havePointerLock = 'pointerLockElement' in document ||
                          'mozPointerLockElement' in document ||
                          'webkitPointerLockElement' in document;

  if (!havePointerLock) {
    console.warn("Pointer Lock API not supported");
    orbit.enabled = true;
    return;
  }

  const requestPointerLock = () => {
    element.requestPointerLock = element.requestPointerLock ||
                                 element.mozRequestPointerLock ||
                                 element.webkitRequestPointerLock;
    element.requestPointerLock().catch(e => {
      console.error("PointerLock error:", e);
    });
  };

  element.addEventListener('click', () => {
    if (!document.pointerLockElement) {
      requestPointerLock();
    }
  }, false);

  const pointerlockchange = () => {
    if (document.pointerLockElement === element) {
      controls.enabled = true;
      orbit.enabled = false;
    } else {
      controls.enabled = false;
      orbit.enabled = true;
    }
  };

  document.addEventListener('pointerlockchange', pointerlockchange, false);
  document.addEventListener('mozpointerlockchange', pointerlockchange, false);
  document.addEventListener('webkitpointerlockchange', pointerlockchange, false);
}
