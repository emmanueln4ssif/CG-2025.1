// guns.js
import * as THREE from 'three';
import { setDefaultMaterial } from '../libs/util/util.js';

const bullets = [];
let isShooting = false;
let lastShotTime = 0;
const fireRate = 500;
const bulletSpeed = 25;
const maxDistance = 100;

let gun;

function createGun(camera) {
  const gunGeometry = new THREE.CylinderGeometry(0.05, 0.05, 0.3, 32);
  const gunMaterial = setDefaultMaterial(0x555555);
  gun = new THREE.Mesh(gunGeometry, gunMaterial);
  gun.scale.set(2, 2, 2);
  gun.position.set(0, -0.4, -1);
  gun.rotation.set(Math.PI / 2, 0, 0);
  camera.add(gun);
}

function setupCrosshair() {
  const crosshair = document.createElement('img');
  crosshair.src = 'assets/crosshair.png';
  crosshair.style.position = 'absolute';
  crosshair.style.width = '100px';
  crosshair.style.height = '100px';
  crosshair.style.top = '50%';
  crosshair.style.left = '50%';
  crosshair.style.transform = 'translate(-50%, -50%)';
  crosshair.style.pointerEvents = 'none';
  crosshair.style.zIndex = '1000';
  document.body.appendChild(crosshair);
}

function handleMouseEvents() {
  window.addEventListener('mousedown', () => isShooting = true);
  window.addEventListener('mouseup', () => isShooting = false);
}

function checkBulletCollision(bulletPosition, collisionObjects) {
  const bulletRadius = 0.05;

  for (const object of collisionObjects) {
    if (!object) continue;

    const objectBox = new THREE.Box3();
    try {
      objectBox.setFromObject(object);
    } catch (e) {
      console.warn("Error setting object box for bullet:", e);
      continue;
    }

    const closestPoint = new THREE.Vector3();
    objectBox.clampPoint(bulletPosition, closestPoint);
    const distance = bulletPosition.distanceTo(closestPoint);

    if (distance < bulletRadius) {
      return true;
    }
  }
  return false;
}

function shoot(camera, scene) {
  const bulletGeometry = new THREE.SphereGeometry(0.25, 8, 8);
  const bulletMaterial = setDefaultMaterial('black');
  const bullet = new THREE.Mesh(bulletGeometry, bulletMaterial);

  const gunWorldPosition = new THREE.Vector3();
  gun.getWorldPosition(gunWorldPosition);

  const barrelOffset = new THREE.Vector3(0, 0, 2);
  barrelOffset.applyQuaternion(gun.quaternion);

  bullet.position.copy(gunWorldPosition);
  bullet.position.add(barrelOffset);

  const direction = new THREE.Vector3();
  camera.getWorldDirection(direction);

  bullets.push({
    mesh: bullet,
    direction: direction.clone().normalize(),
    startPosition: bullet.position.clone()
  });

  scene.add(bullet);
}

function updateBullets(delta, scene, collisionObjects) {
  const toRemove = [];

  bullets.forEach((bulletData, index) => {
    const { mesh, direction, startPosition } = bulletData;

    mesh.position.add(direction.clone().multiplyScalar(bulletSpeed * delta * 200));

    const traveled = mesh.position.distanceTo(startPosition);
    if (traveled > maxDistance || checkBulletCollision(mesh.position, collisionObjects)) {
      toRemove.push(index);
    }
  });

  toRemove.reverse().forEach(i => {
    scene.remove(bullets[i].mesh);
    bullets.splice(i, 1);
  });
}

function tryToShoot(currentTime, camera, scene) {
  if (isShooting && (currentTime - lastShotTime >= fireRate)) {
    shoot(camera, scene);
    lastShotTime = currentTime;
  }
}

export {
  createGun,
  setupCrosshair,
  handleMouseEvents,
  updateBullets,
  tryToShoot
};
