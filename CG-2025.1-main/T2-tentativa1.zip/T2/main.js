// main.js
import * as THREE from 'three';
import { initRenderer, initCamera, initDefaultBasicLight, onWindowResize } from '../libs/util/util.js';
import { OrbitControls } from '../build/jsm/controls/OrbitControls.js';
import KeyboardState from '../libs/util/KeyboardState.js';
import { setupPointerLock } from './src/player.js';
import { shoot, updateBullets, setupShooting } from './src/guns.js';
import { createScenario, getCollisionObjects } from './src/environment.js';

const scene = new THREE.Scene();
const renderer = initRenderer();
renderer.setClearColor("rgb(70, 151, 198)");
const camera = initCamera(new THREE.Vector3(0.0, 0.0, -10));
const light = initDefaultBasicLight(scene);

// OrbitControls and PointerLockControls setup
const orbit = new OrbitControls(camera, renderer.domElement);
const controls = new PointerLockControls(camera, renderer.domElement);
scene.add(controls.getObject());

// Setup pointer lock interaction
setupPointerLock(renderer, controls, orbit);

// Create scene (ground, walls, platforms)
createScenario(scene);
scene.add(light);

// Setup gun and shooting
setupShooting(camera, scene);

// Keyboard listeners
window.addEventListener('keydown', (event) => movementControls(event.keyCode, true));
window.addEventListener('keyup', (event) => movementControls(event.keyCode, false));

// Resize listener
window.addEventListener('resize', () => onWindowResize(camera, renderer), false);

// Animation loop
const clock = new THREE.Clock();
function render() {
  const delta = Math.min(clock.getDelta(), 0.1);
  updatePlayer(delta, controls, camera, getCollisionObjects());
  updateBullets();
  renderer.render(scene, camera);
  requestAnimationFrame(render);
}
render();
